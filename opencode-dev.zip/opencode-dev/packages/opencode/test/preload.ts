import { Log } from "../src/util/log"

Log.init({
  print: false,
  dev: true,
  level: "DEBUG",
})
