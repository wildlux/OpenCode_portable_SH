ALTER TABLE `account` ADD PRIMARY KEY(`id`);--> statement-breakpoint
ALTER TABLE `auth` ADD PRIMARY KEY(`id`);