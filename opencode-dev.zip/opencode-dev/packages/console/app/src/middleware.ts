import { defineMiddleware } from "vinxi/http"

export default defineMiddleware({
  onBeforeResponse() {},
})
